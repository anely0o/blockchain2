const Web3 = require('web3');
const web3 = new Web3('HTTP://127.0.0.1:7545');
const fs = require('fs');

async function main(){
    const account = web3.eth.accounts.privateKeyToAccount("0x4121bffe28940174d5c6488242ec3fbc737d354d8bb664b1963398d48d982216") //address: 0x03E3ebD94c07F209758ACc4B2efcB8783140A0cF
    const users = ['0xcb6cFD3B46faBa01Ca1C17CA151665c7971E5539', '0x7BB08D5dbb4CA70A007e2317dB20b6E4821a5982', '0x4A749f137eD8e5A07e1d81D34a9d8D87b385c289']
    const amount = 100
    const ABI = JSON.parse(fs.readFileSync(__dirname + '/' + 'ERC20.abi', 'utf-8'))
    const bytecode = fs.readFileSync(__dirname + '/' + 'ERC20.bin', 'utf-8')
    console.log(ABI)
    console.log(bytecode)
    let myContract = new web3.eth.Contract(ABI)

    let deployGas = await myContract.deploy({data: bytecode, arguments :['MyToken', 'MT', 18]}).estimateGas({from:account.address})
    console.log(deployGas)
    await myContract.deploy({data: bytecode, arguments :['MyToken', 'MT', 18]})
    .send({
        from : account.address,
        gas: deployGas
    })
    .then((newContractInstance) => {
        myContract = newContractInstance
    })
    console.log(`Contract deployed at: ${myContract._address}`)

    console.log('=========Calling free methods of contract=========')
    await myContract.methods.name().call()
        .then((result) => {console.log(`Name of token ${result}`)})
    
    await myContract.methods.symbol().call()
        .then((result) => {console.log(`Symbol of token ${result}`)})
    
    await myContract.methods.decimals().call()
        .then((result) => {console.log(`Decimals of token ${result}`)})

    await myContract.methods.totalSupply().call()
        .then((result) => {console.log(`Total supply of tokens ${result}`)})
    console.log('==================================================')
    console.log('=========Calling payable methods of contract=========')
    let estimateGas = await myContract.methods.mint(users[0], amount).estimateGas({from:account.address})
    await myContract.methods.mint(users[0], amount).send({from:account.address, gas:estimateGas})
        .then(console.log(`Minted ${amount} tokens on ${users[0]} account`))
    
    await myContract.methods.balanceOf(users[0]).call()
        .then((result) => {console.log(`Balance of ${users[0]}: ${result} tokens`)})

    estimateGas = await myContract.methods.transfer(users[1], amount).estimateGas({from:users[0]})
    await myContract.methods.transfer(users[1], amount).send({from:users[0], gas:estimateGas})
        .then(console.log(`Transfered from ${users[0]} to ${users[1]} ${amount} tokens`))

    await myContract.methods.balanceOf(users[0]).call()
        .then((result) => {console.log(`Balance of ${users[0]}: ${result} tokens`)})

    await myContract.methods.balanceOf(users[1]).call()
        .then((result) => {console.log(`Balance of ${users[1]}: ${result} tokens`)})
}

main()